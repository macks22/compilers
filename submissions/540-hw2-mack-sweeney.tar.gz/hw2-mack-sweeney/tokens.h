#define NT   1
#define T    2
#define GOES 3
#define SEMI 4
#define OR   5
#define EOL  6
#define OTHER -1
